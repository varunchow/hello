import React, { Component } from "react";

class LifecycleDemo
 extends Component {
  constructor(props) {
    super(props);

    this.state = {
      count: 0
    };

    console.log("1. Constructor called");
  }

  componentDidMount()   // This method is called AFTER the component's state inserted into the webpage (DOM).
{
    console.log("2. Component Did Mount");
  }

  componentDidUpdate(prevProps, prevState) {
    console.log("3. Component Did Update");
    console.log("Previous count:", prevState.count);
    console.log("Current count:", this.state.count);
  }

  componentWillUnmount() {
    console.log("4. Component Will Unmount");
  }

  increaseCount = () => {
    this.setState({
      count: this.state.count + 1
    });
  };

  render() {
    console.log("Render called");

    return (
      <div style={{ textAlign: "center", marginTop: "50px" }}>
        <h1>React Component Lifecycle</h1>

        <h2>Count: {this.state.count}</h2>

        <button onClick={this.increaseCount}>
          Increase Count
        </button>
      </div>
    );
  }
}

class App extends Component {
  state = {
    show: true
  };

  toggleComponent = () => {
    this.setState({
      show: !this.state.show
    });
  };

  render() {
    return (
      <div>
        {this.state.show && <LifecycleDemo />}

        <button onClick={this.toggleComponent}>
          Mount / Unmount Component
        </button>
      </div>
    );
  }
}

export default App;