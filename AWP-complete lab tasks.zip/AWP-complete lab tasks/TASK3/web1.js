const http = require('http');

const server = http.createServer((request, response) => {

    response.writeHead(200, { 'Content-Type': 'text/html' });

    response.write("<h1>Welcome to Node.js</h1>");
    response.write("<h2>Home Page</h2>");
    response.write("<p>This is my first web server.</p>");

    response.end();

});

server.listen(3000, () => {
    console.log("Server is running at http://localhost:3000");
});