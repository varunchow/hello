const http = require("http");

const port = 8000;

const server = http.createServer(function (request, response) {
    response.setHeader("Content-Type", "text/html");

    if (request.url === "/home") {
        response.write("<h1 style='color:red'>Welcome to Home page of my website</h1>");
        response.write("<h2>Home page</h2>");
        response.end();
    } 
    else if (request.url === "/login") {
        response.write("<h1 style='color:red'>Welcome to Login page of my website</h1>");
        response.write("<h2>Login page</h2>");
        response.end();
    } 
    else {
        response.statusCode = 404;
        response.write("<h1>404 - Page Not Found</h1>");
        response.end();
    }
});

server.listen(port, function () {
    console.log("Server Started...");
    console.log("Server is listening on " + port);
});