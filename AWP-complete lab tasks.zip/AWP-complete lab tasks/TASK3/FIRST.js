console.log("Welcome to Node.js");
console.log("This is my first Node.js program.");