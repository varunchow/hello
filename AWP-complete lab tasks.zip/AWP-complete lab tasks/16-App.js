import React, { useState } from "react";
import {
  BrowserRouter,
  Routes,
  Route,
  Link,
  useNavigate
} from "react-router-dom";
import "./App.css";

const books = [
  { id: 1, title: "Python Programming", price: 500 },
  { id: 2, title: "Web Technologies", price: 450 },
  { id: 3, title: "Data Science", price: 600 }
];

function Home({ addToCart }) {
  return (
    <div>
      <h1>📚 Book Store</h1>

      <div className="books">
        {books.map((book) => (
          <div className="book" key={book.id}>
            <h2>{book.title}</h2>
            <p>₹{book.price}</p>

            <Link to={"/product/" + book.id}>
              <button>View Product</button>
            </Link>

            <button onClick={() => addToCart(book)}>
              Add to Cart
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

function Product({ addToCart }) {
  const id = window.location.pathname.split("/")[2];
  const book = books.find((b) => b.id == id);

  return (
    <div className="product">
      <h1>📖 {book.title}</h1>
      <h2>Price: ₹{book.price}</h2>

      <button onClick={() => addToCart(book)}>
        Add to Cart
      </button>
    </div>
  );
}

function Cart({ cart }) {
  const total = cart.reduce(
    (sum, book) => sum + book.price,
    0
  );

  return (
    <div className="cart">
      <h1>🛒 Shopping Cart</h1>

      {cart.length === 0 ? (
        <h2>Your cart is empty</h2>
      ) : (
        <>
          {cart.map((book, index) => (
            <p key={index}>
              {book.title} - ₹{book.price}
            </p>
          ))}

          <h2>Total: ₹{total}</h2>

          <Link to="/checkout">
            <button>Checkout</button>
          </Link>
        </>
      )}
    </div>
  );
}

function Checkout({ cart }) {
  const total = cart.reduce(
    (sum, book) => sum + book.price,
    0
  );

  return (
    <div className="invoice">
      <h1>🧾 BOOK STORE INVOICE</h1>

      <hr />

      {cart.map((book, index) => (
        <p key={index}>
          {book.title} - ₹{book.price}
        </p>
      ))}

      <hr />

      <h2>Total Amount: ₹{total}</h2>

      <h3>Thank You for Shopping! 😊</h3>
    </div>
  );
}

function App() {
  const [cart, setCart] = useState([]);

  const addToCart = (book) => {
    setCart([...cart, book]);
    alert("Book added to cart!");
  };

  return (
    <BrowserRouter>
      <nav>
        <Link to="/">🏠 Home</Link>
        <Link to="/cart">🛒 Cart ({cart.length})</Link>
        <Link to="/checkout">🧾 Checkout</Link>
      </nav>

      <Routes>
        <Route
          path="/"
          element={<Home addToCart={addToCart} />}
        />

        <Route
          path="/product/:id"
          element={<Product addToCart={addToCart} />}
        />

        <Route
          path="/cart"
          element={<Cart cart={cart} />}
        />

        <Route
          path="/checkout"
          element={<Checkout cart={cart} />}
        />
      </Routes>
    </BrowserRouter>
  );
}

export default App;