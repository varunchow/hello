import React from "react";

function App() {
  const currentDateTime = new Date().toLocaleString();

  return (
    <div>
      <h1>Current System Date and Time</h1>
      <p>{currentDateTime}</p>
    </div>
  );
}

export default App;