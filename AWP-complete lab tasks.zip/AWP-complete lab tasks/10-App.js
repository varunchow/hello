import React, { Component } from "react";
import DateDisplay from "./DateDisplay";

// Creating a class component named App
class App extends Component {

  // Constructor is used to initialize the state
  constructor(props) {
    super(props);

    // Creating state and storing the date
    this.state = {
      date: "28-09-2026"
    };
  }

  // render() defines what should be displayed on the screen
  render() {
    return (
      <div>

        {/* Displaying a heading */}
        <h1>Props vs State</h1>

        {/* 
          Passing the date from state to the child component
          as a prop
        */}
        <DateDisplay date={this.state.date} />

      </div>
    );
  }
}

// Exporting App component
export default App;