import React, { Component } from "react";

// Creating a class component named DateDisplay
class DateDisplay extends Component {

  // render() defines what should be displayed
  render() {
    return (
      <div>

        {/* 
          Receiving the date through props
          and displaying it
        */}
        <h2>Date: {this.props.date}</h2>

      </div>
    );
  }
}

// Exporting DateDisplay component
export default DateDisplay;