import React from "react";
import Greeting from "./9a_Greeting";
import GreetingClass from "./9b_GreetingClass";

function App() {
  return (
    <div>
      <Greeting name="Alice" />
      <GreetingClass name="Bob" />
    </div>
  );
}

export default App;
